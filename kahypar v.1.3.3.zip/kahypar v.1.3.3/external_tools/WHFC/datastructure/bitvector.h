#pragma once

#include <boost/dynamic_bitset.hpp>

namespace whfc {
	using BitVector = boost::dynamic_bitset<>;
}