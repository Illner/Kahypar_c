#pragma once

namespace whfc {
	template <typename... Types> void unused(Types&& ...) { }
}