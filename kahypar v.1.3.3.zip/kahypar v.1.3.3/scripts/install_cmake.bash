curl -OL https://cmake.org/files/v3.17/cmake-3.17.2-Linux-x86_64.sh
bash cmake-3.17.2-Linux-x86_64.sh --skip-license --prefix=/usr
